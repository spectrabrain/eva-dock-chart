# EVA-Dock Helm Chart

이 차트는 EVA-Dock 백엔드와 영구 데이터 볼륨을 배포합니다. Ingress 생성은 선택이며,
기존 Ingress를 쓸 때는 `ingress.enabled=false`로 두고 차트 Service의 80번 포트로 연결합니다.

## 기본 구성

- ECR 이미지: `values.yaml`의 `image.repository`와 `image.tag`
- ConfigMap: 일반 설정을 컨테이너 환경변수로 전달
- Kubernetes Secret: 비밀번호, MySQL 자격증명 등 민감 환경변수 전달
- PVC: SQLite DB(`/data/eva_live.db`)에 알림 이력, 카메라 카탈로그, EVA 등록 정보와 화면 정책을 보존
- Service: 클러스터 내부 HTTP 80번 포트
- Ingress: 선택 생성. 기존 Ingress를 사용하면 비활성 상태로 둡니다.

SQLite를 한 파일에 쓰므로 기본 replica 수는 1입니다. 이 차트는 Caddy를 배포하지 않으며,
TLS 종료는 Ingress가 담당하는 구성을 기본으로 합니다. EVA-Dock은 `/`와 `/api/...` 경로를
사용하므로 Ingress에서는 전용 호스트 사용을 권장합니다.

대시보드의 EVA 피드백·최근 알림 조회는 `config.dashboardApiConcurrency`로 전체 동시 요청 수를
조절합니다. 기본값은 32이며, EVA별 동시 요청과 피드백 페이지 병렬 조회는 각각 8개로 제한됩니다.
`ingress.host`에 IP 주소를 지정하면 Kubernetes Ingress host 필드를 생략한 규칙을 생성합니다.
이 경우 TLS 인증서에 접속 IP가 SAN으로 포함되어야 하며, 자체 서명 인증서는 접속 클라이언트에서 신뢰하도록 설정해야 합니다.

Ingress를 켜면 Service는 기본적으로 `ClusterIP`, 끄면 `NodePort`가 됩니다. NCP 콘솔에서
ALB가 노드 포트로 직접 연결되는 구성은 Ingress를 끄고, 필요하면 `service.nodePort`에
클러스터에서 사용 가능한 고정 NodePort를 지정합니다. 기본 Kubernetes 범위는 30000-32767입니다.
일반 Ingress Controller를
사용하는 Kubernetes 환경에서는 Ingress를 켜고 `ingress.className`과 annotation을 설정합니다.

## 알림 이미지 보관

이미지 보관은 브라우저 탭과 독립적으로 Dock 백엔드가 EVA Analysis API를 주기 조회하는 기능입니다.
`alert=true`인 항목의 Raw JSON과 BBox JPEG를 `/data/alert-images`에 저장하며, 대시보드 화면의
최근 50건 제한과 Live 화면 상태는 보관 범위에 영향을 주지 않습니다. 초기 수집 및 재시작 후 따라잡기는
기본 최근 3일이고, EVA별 커서와 재시도 작업은 별도 SQLite 파일 `/data/image_archive.db`에 기록됩니다.
이 파일은 기존 `/data` 영구 볼륨에 생성되므로 새 DB 서버나 볼륨은 필요하지 않습니다.

기능은 기본 비활성화되어 있습니다. 활성화하려면 암호화 키를 Secret으로 전달하고 다음 설정을 켭니다.

```yaml
config:
  imageArchiveEnabled: true
  imageArchivePollSec: 180
  imageArchiveBackfillDays: 3
  imageArchiveOverlapSec: 240
  imageArchiveBatchSize: 250
  imageArchiveRetentionDays: 0 # 0이면 삭제하지 않고 계속 보관
  imageArchiveRawEncryptionEnabled: true
  imageArchiveBboxEncryptionEnabled: false

secrets:
  imageArchiveEncryptionKeySecret: eva-dock-image-archive-key
```

Kubernetes Secret은 최초 한 번 생성하고, 생성된 키를 별도 비밀 저장소에도 백업합니다.

```bash
kubectl create secret generic eva-dock-image-archive-key \
  --namespace eva-dock \
  --from-file=IMAGE_ARCHIVE_ENCRYPTION_KEY=<(openssl rand -hex 32)
```

키는 임의의 비어 있지 않은 문자열이면 됩니다. Dock은 UTF-8 문자열의 SHA-256 해시를 AES-256 키로 사용합니다.
Docker에서는 `openssl rand -hex 32`로 생성한 문자열을 `.env`의 `IMAGE_ARCHIVE_ENCRYPTION_KEY`에 저장합니다.
키 문자열을 바꾸면 기존 암호화 파일을 복호화할 수 없으므로 백업하고 계속 같은 키를 사용해야 합니다.
키가 비어 있으면 보관 기능이 활성화된 Dock은 시작하지 않습니다.

Raw JSON은 기본 AES-256-GCM 암호화, BBox JPEG는 기본 평문 저장입니다. 두 설정은 독립적으로 바꿀 수
있습니다. Dock은 EVA의 M2M 인증 GET으로 이미지를 받고, BBox fallback을 응답할 때 필요한 경우 복호화합니다.
암호화 on/off 변경은 이후 새로 내려받는 파일부터 적용되고, 기존 파일은 저장 당시의 암호화 상태를 유지합니다.
Live와 대시보드가 사용하는 `/api/snapshot`은 EVA 원본 이미지가 없거나 접근할 수 없을 때 보관된 BBox를
찾아 반환합니다. Raw JSON은 암호화된 상태로 로컬에 보관하며, 현재 이를 조회하는 API는 제공하지 않습니다.

경로는 사업장 그룹, EVA 서버 이름, 카메라, UTC 날짜 순으로 구성됩니다.

```text
/data/alert-images/{사업장}/{서버명}__{eva_id}/camera-{seq}/YYYY/MM/DD/
├── {analysis_id}_raw.json
└── {analysis_id}_bbox.jpg
```

### IP 접속에 전용 HTTPS NodePort 사용 (Traefik)

DNS 없이 IP로 접속하고 EVA-App과 Dock의 `/` 경로가 겹치는 환경에서는 Dock 전용 Traefik
entrypoint와 NodePort를 구성합니다. Dock values에는 entrypoint 이름과 외부 접속 URL을 설정하고,
Traefik에는 같은 이름의 entrypoint를 만들고 해당 포트를 NodePort로 노출해야 합니다.
Ingress annotation만으로 Traefik entrypoint나 외부 포트가 만들어지지는 않습니다.

예를 들어 `docksecure` entrypoint를 NodePort `32020`으로 노출하는 경우 Dock values는 다음과 같습니다.

```yaml
ingress:
  enabled: true
  className: traefik
  host: "222.108.131.192"
  annotations:
    traefik.ingress.kubernetes.io/router.entrypoints: docksecure
    traefik.ingress.kubernetes.io/router.tls: "true"
  tls:
    enabled: true
    secretName: eva-dock-tls
    # Secret 생성 방식은 해당 환경에 맞게 설정

config:
  dockPublicUrl: "https://222.108.131.192:32020"
```

Traefik 설치 설정에서는 `docksecure` entrypoint를 정의하고, Traefik Service의 외부 NodePort
`32020`이 그 entrypoint로 연결되도록 설정합니다. 이 값들은 Traefik 배포 방식과 Helm chart 버전에
따라 설정 위치와 형식이 다를 수 있습니다. EVA-App과 같은 IP 기반 hostless Ingress가 같은
entrypoint를 공유하면 `/` 경로가 겹칠 수 있으므로, Dock 전용 entrypoint를 사용할 때는 Ingress
annotation에도 그 이름을 지정해야 합니다.

`ingress.tls.secretName`의 TLS Secret은 Ingress와 같은 namespace에 있어야 합니다. IP로 HTTPS에
접속하려면 인증서에 해당 IP가 SAN으로 포함되어야 합니다. 자체 서명 또는 신뢰되지 않는 인증서도
TLS 연결은 가능하지만 브라우저에 인증서 경고가 표시됩니다. `dockPublicUrl`의 scheme, IP, 포트는
사용자가 실제 접속하는 HTTPS 주소와 일치시킵니다.

EVA-App on-premise와 같은 Traefik/hostPath 구성은 다음 values 파일을 추가합니다.

```sh
helm upgrade --install eva-dock ./deploy/helm/eva-dock \
  --namespace eva-dock --create-namespace \
  -f ./deploy/helm/eva-dock/platform/onpremise/values.yaml
```

프로필은 Traefik Ingress와 `eva-tls` Secret을 사용하고, 데이터를 hostPath에 저장합니다.
Helm hook Job이 `/root/certs/tls_dock.crt`와 `/root/certs/tls_dock.key`를 읽어 `eva-tls` Secret을 만듭니다.
Job이 실행될 노드에서 인증서 경로를 사용할 수 있어야 합니다. 앱 컨테이너는 EVA-App처럼 root로
실행하므로 hostPath 소유권을 별도로 변경하지 않아도 기록할 수 있습니다. hostPath는 노드 경로이므로,
노드 이동 시에도 데이터 경로가 같은 저장소를 가리키도록 노드 구성을 맞춰야 합니다.
인증서를 Kubernetes Secret으로 이미 관리한다면 `ingress.tls.create: false`로
두고 `ingress.tls.secretName`에 해당 Secret 이름을 지정합니다.

## 앱 민감값

초기 설치에서는 `values.yaml`의 다음 항목을 입력하면 차트가 Kubernetes Secret을 만들고
컨테이너 환경변수로 전달합니다.

```yaml
secrets:
  dockAccessPassword: "Dock 로그인 비밀번호"
  evaMysqlUser: ""
  evaMysqlPassword: ""
```

MySQL 계정은 feedback 조회를 DB로 설정한 경우에만 필요합니다. 기존 Secret을 쓰려면
`secrets.existingSecret`에 이름을 지정할 수 있습니다.

## 이미지 pull 인증 (ECR / Harbor)

`imagePullSecrets`는 기존 pull Secret 목록으로 계속 사용할 수 있습니다. `imagePullSecret`은
EVA-App과 같은 관리 모드로, ECR Secret 자동 생성/갱신 또는 기존 Secret 참조를 설정합니다.

### ECR Secret 자동 생성 및 갱신

Kubernetes 노드에 AWS CLI profile이 있는 경우 해당 경로를 마운트하고 profile 이름을 지정합니다.
이 Job이 설치 직후 Secret을 만든 뒤 기본 10분 주기로 갱신합니다(ECR 토큰은 12시간 유효).

```yaml
imagePullSecret:
  enabled: true
  create: true
  existingSecret: ""
  nameOverride: ecr-pull-secret
  account: "211722900905"
  region: ap-northeast-2
  authType: hostPath
  hostPath: /home/eva/.aws
  awsProfile: eva-dock-ecr
```

`hostPath`는 Helm 명령을 실행하는 PC가 아니라 Job이 배치되는 Kubernetes 노드의 경로입니다.
키 값을 담은 Secret을 사용할 때는 `authType: secret`과 `awsCredentialsSecret`을 지정합니다.
private registry에 있는 AWS CLI/kubectl 보조 이미지에는 `jobImagePullSecrets`를 지정할 수 있습니다.

### 기존 Harbor pull Secret 사용

Secret을 `eva-dock` namespace에 미리 만들고 다음처럼 참조합니다.

```yaml
imagePullSecret:
  enabled: true
  create: false
  existingSecret: harbor-pull-secret
```

인증 없이 pull 가능한 Harbor 프로젝트라면 `imagePullSecret.enabled: false`로 두고
`imagePullSecrets`를 비웁니다. 기존 Secret 목록(`imagePullSecrets`)은 앱 Pod와 TLS Job의
기본 pull 인증에 사용되며, TLS 보조 이미지 전용 Secret은 `ingress.tls.job.imagePullSecrets`로
지정할 수 있습니다. HTTP Harbor는 인증 Secret과 별개로 Kubernetes 노드의 컨테이너 런타임이
HTTP 레지스트리를 허용하도록 설정되어야 합니다.

## 설치 예시

다음 명령으로 설치합니다.

```sh
helm upgrade --install eva-dock ./deploy/helm/eva-dock \
  --namespace eva-dock --create-namespace \
  -f ./deploy/helm/eva-dock/values.yaml
```

이미지 태그, 기능 플래그, PVC 크기, Ingress 옵션은 `values.yaml` 또는 별도 환경별 values 파일로
조정합니다. 기존 Ingress를 쓸 때는 해당 Ingress의 backend를 배포된 Service의 80번 포트로
지정하면 됩니다. SSE와 MJPEG 스트림 경로는 장시간 연결을 허용하도록 Ingress를 설정해야 합니다.
